package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Блок постройки. Уровни: 0 дерево, 1 камень, 2 металл, 3 бронированный, 4 хворост.
 * Блок нельзя сломать руками как обычный: у элемента есть HP (см. StructureHealth),
 * его снижают взрывчаткой или (дерево/хворост, чуть-чуть камень) инструментами.
 */
public class BuildingBlock extends Block {
    public static final String[] TIER_NAMES = {"Дерево", "Камень", "Металл", "Бронированный", "Хворост"};

    public final int tier;

    public BuildingBlock(Properties props, int tier) {
        super(props);
        this.tier = tier;
    }

    /** Урон по постройке одним ударом: [хворост, дерево, камень, металл, бронированный] по типу предмета. */
    private static float melee(Player p, int tier) {
        Item it = p.getMainHandItem().getItem();
        boolean axe = it instanceof AxeItem;
        boolean pick = it instanceof PickaxeItem;
        boolean sword = it instanceof SwordItem;
        return switch (tier) {
            case StructureHealth.TWIG -> (axe || pick || sword) ? 10.0F : 3.0F;
            case 0 -> axe ? 6.0F : (sword ? 3.0F : (pick ? 2.0F : 0.5F));
            case 1 -> pick ? 1.2F : (axe ? 0.4F : 0.0F);
            case 2 -> pick ? 0.5F : 0.0F;
            default -> 0.0F;
        };
    }

    /** Клик ЛКМ по блоку (приходит на сервер в начале каждого клика). */
    @Override
    @SuppressWarnings("deprecation")
    public void attack(BlockState state, Level level, BlockPos pos, Player player) {
        if (!(level instanceof ServerLevel sl)) return;
        long now = sl.getGameTime();
        if (now - player.getPersistentData().getLong("rust_wall_hit") < StructureHealth.MELEE_DELAY) return;
        player.getPersistentData().putLong("rust_wall_hit", now);
        BuildingData data = BuildingData.get(sl);
        BuildingData.Piece piece = data.at(pos);
        if (piece == null) return;
        float dmg = melee(player, piece.tier);
        if (dmg <= 0.0F) {
            player.displayClientMessage(StructureDamage.hud(piece), true);
            return;
        }
        StructureDamage.damage(sl, data, piece, dmg, player, Vec3.atCenterOf(pos));
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        // при улучшении (замена на блок другого уровня) запись о постройке сохраняем
        if (!(newState.getBlock() instanceof BuildingBlock) && level instanceof ServerLevel sl) {
            BuildingData.get(sl).removePos(pos);
        }
        super.onRemove(state, level, pos, newState, moving);
    }
}
