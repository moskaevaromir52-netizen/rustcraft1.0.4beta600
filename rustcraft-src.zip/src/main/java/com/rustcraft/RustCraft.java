package com.rustcraft;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(RustCraft.MODID)
public class RustCraft {
    public static final String MODID = "rustcraft";

    public RustCraft() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEffects.EFFECTS.register(bus);
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModMenus.MENUS.register(bus);
        RustNet.init();
        ModItems.TABS.register(bus);
        MinecraftForge.EVENT_BUS.register(new RustEvents());
    }
}
