package com.rustcraft;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, RustCraft.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RustCraft.MODID);

    private static final Map<String, RegistryObject<Item>> BY_ID = new LinkedHashMap<>();
    /** Вкладка «RustCraft»: ресурсы, патроны, блоки, бинт. */
    public static final List<RegistryObject<Item>> MISC = new ArrayList<>();
    /** Вкладка «Оружие». */
    public static final List<RegistryObject<Item>> WEAPONS = new ArrayList<>();
    /** Вкладка «Одежда и броня». */
    public static final List<RegistryObject<Item>> ARMOR = new ArrayList<>();

    private static RegistryObject<Item> reg(List<RegistryObject<Item>> tab, String id, Supplier<Item> sup) {
        RegistryObject<Item> r = ITEMS.register(id, sup);
        BY_ID.put(id, r);
        tab.add(r);
        return r;
    }

    /** Предмет мода по id (без неймспейса). */
    public static Item get(String id) {
        return BY_ID.get(id).get();
    }

    public static final RegistryObject<Item> SCRAP = reg(MISC, "scrap",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> BANDAGE = reg(MISC, "bandage",
            () -> new BandageItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> SLEEPING_BAG = reg(MISC, "sleeping_bag",
            () -> new BlockItem(ModBlocks.SLEEPING_BAG.get(), new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> TOOL_CUPBOARD = reg(MISC, "tool_cupboard",
            () -> new BlockItem(ModBlocks.TOOL_CUPBOARD.get(), new Item.Properties()));

    static {
        // ---- патроны, ресурсы, план строительства, блоки построек
        reg(MISC, "pistol_bullet", () -> new Item(new Item.Properties()));
        reg(MISC, "rifle_ammo", () -> new Item(new Item.Properties()));
        reg(MISC, "handmade_shell", () -> new Item(new Item.Properties()));
        reg(MISC, "buckshot", () -> new Item(new Item.Properties()));
        reg(MISC, "nails", () -> new Item(new Item.Properties()));
        reg(MISC, "rocket", () -> new Item(new Item.Properties()));
        reg(MISC, "grenade_40mm", () -> new Item(new Item.Properties()));
        reg(MISC, "low_grade_fuel", () -> new Item(new Item.Properties()));
        reg(MISC, "cloth", () -> new Item(new Item.Properties()));
        reg(MISC, "metal_fragments", () -> new Item(new Item.Properties()));
        reg(MISC, "hq_metal", () -> new Item(new Item.Properties()));
        // ---- компоненты оружия (крафтятся на верстаках, редко выпадают из бочек)
        reg(MISC, "metal_pipe", () -> new Item(new Item.Properties()));
        reg(MISC, "rope", () -> new Item(new Item.Properties()));
        reg(MISC, "gears", () -> new Item(new Item.Properties()));
        reg(MISC, "metal_spring", () -> new Item(new Item.Properties()));
        reg(MISC, "semi_auto_body", () -> new Item(new Item.Properties()));
        reg(MISC, "smg_body", () -> new Item(new Item.Properties()));
        reg(MISC, "rifle_body", () -> new Item(new Item.Properties()));
        reg(MISC, "propane_tank", () -> new Item(new Item.Properties()));
        // ---- верстаки и бочка
        reg(MISC, "workbench_1", () -> new BlockItem(ModBlocks.WORKBENCH_1.get(), new Item.Properties()));
        reg(MISC, "workbench_2", () -> new BlockItem(ModBlocks.WORKBENCH_2.get(), new Item.Properties()));
        reg(MISC, "workbench_3", () -> new BlockItem(ModBlocks.WORKBENCH_3.get(), new Item.Properties()));
        reg(MISC, "barrel", () -> new BlockItem(ModBlocks.BARREL.get(), new Item.Properties()));
        reg(MISC, "building_plan", () -> new BuildingPlanItem(new Item.Properties().stacksTo(1)));
        reg(MISC, "twig_building", () -> new BlockItem(ModBlocks.TWIG_BUILDING.get(), new Item.Properties()));
        reg(MISC, "wood_building", () -> new BlockItem(ModBlocks.WOOD_BUILDING.get(), new Item.Properties()));
        reg(MISC, "stone_building", () -> new BlockItem(ModBlocks.STONE_BUILDING.get(), new Item.Properties()));
        reg(MISC, "metal_building", () -> new BlockItem(ModBlocks.METAL_BUILDING.get(), new Item.Properties()));
        reg(MISC, "armored_building", () -> new BlockItem(ModBlocks.ARMORED_BUILDING.get(), new Item.Properties()));
        // ---- оружие и инструменты
        reg(WEAPONS, "rock", () -> new SwordItem(Tiers.WOOD, 1, -2.4F, new Item.Properties()));
        reg(WEAPONS, "bone_club", () -> new SwordItem(Tiers.WOOD, 3, -2.6F, new Item.Properties()));
        reg(WEAPONS, "bone_knife", () -> new SwordItem(Tiers.WOOD, 2, -1.8F, new Item.Properties()));
        reg(WEAPONS, "wooden_spear", () -> new SwordItem(Tiers.WOOD, 3, -2.4F, new Item.Properties()));
        reg(WEAPONS, "stone_spear", () -> new SwordItem(Tiers.STONE, 3, -2.4F, new Item.Properties()));
        reg(WEAPONS, "stone_hatchet", () -> new AxeItem(Tiers.STONE, 6.5F, -3.2F, new Item.Properties()));
        reg(WEAPONS, "stone_pickaxe", () -> new PickaxeItem(Tiers.STONE, 1, -2.8F, new Item.Properties()));
        reg(WEAPONS, "hatchet", () -> new AxeItem(Tiers.IRON, 6.0F, -3.1F, new Item.Properties()));
        reg(WEAPONS, "pickaxe", () -> new PickaxeItem(Tiers.IRON, 1, -2.8F, new Item.Properties()));
        reg(WEAPONS, "salvaged_axe", () -> new AxeItem(Tiers.IRON, 7.0F, -3.0F, new Item.Properties()));
        reg(WEAPONS, "salvaged_hammer", () -> new PickaxeItem(Tiers.IRON, 1, -2.8F, new Item.Properties()));
        reg(WEAPONS, "salvaged_icepick", () -> new PickaxeItem(Tiers.IRON, 1, -2.6F, new Item.Properties()));
        reg(WEAPONS, "salvaged_cleaver", () -> new SwordItem(Tiers.IRON, 3, -2.4F, new Item.Properties()));
        reg(WEAPONS, "salvaged_sword", () -> new SwordItem(Tiers.IRON, 3, -2.4F, new Item.Properties()));
        reg(WEAPONS, "machete", () -> new SwordItem(Tiers.IRON, 3, -2.2F, new Item.Properties()));
        reg(WEAPONS, "longsword", () -> new SwordItem(Tiers.IRON, 4, -2.4F, new Item.Properties()));
        reg(WEAPONS, "mace", () -> new SwordItem(Tiers.IRON, 4, -2.8F, new Item.Properties()));
        reg(WEAPONS, "combat_knife", () -> new SwordItem(Tiers.IRON, 2, -1.6F, new Item.Properties()));
        reg(WEAPONS, "baseball_bat", () -> new SwordItem(Tiers.WOOD, 3, -2.6F, new Item.Properties()));
        reg(WEAPONS, "jackhammer", () -> new PickaxeItem(Tiers.DIAMOND, 1, -2.0F, new Item.Properties()));
        reg(WEAPONS, "chainsaw", () -> new AxeItem(Tiers.DIAMOND, 6.0F, -2.0F, new Item.Properties()));
        reg(WEAPONS, "candy_cane_club", () -> new SwordItem(Tiers.WOOD, 3, -2.6F, new Item.Properties()));
        reg(WEAPONS, "paddle", () -> new SwordItem(Tiers.WOOD, 3, -2.6F, new Item.Properties()));
        reg(WEAPONS, "hammer", () -> new HammerItem(new Item.Properties()));
        reg(WEAPONS, "eoka_pistol", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(9.0F, 30, false, "handmade_shell", 4, 0.06F, 40.0, GunItem.Snd.SHOTGUN, GunItem.Mode.BULLET, 0.0F, 4.0F)));
        reg(WEAPONS, "waterpipe_shotgun", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(1.8F, 25, false, "handmade_shell", 8, 0.07F, 45.0, GunItem.Snd.SHOTGUN, GunItem.Mode.BULLET, 0.0F, 5.0F)));
        reg(WEAPONS, "revolver", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(6.0F, 8, false, "pistol_bullet", 1, 0.01F, 70.0, GunItem.Snd.PISTOL, GunItem.Mode.BULLET, 0.0F, 3.0F)));
        reg(WEAPONS, "semi_auto_pistol", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(5.0F, 4, false, "pistol_bullet", 1, 0.015F, 70.0, GunItem.Snd.PISTOL, GunItem.Mode.BULLET, 0.0F, 2.0F)));
        reg(WEAPONS, "python_revolver", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(9.0F, 10, false, "pistol_bullet", 1, 0.008F, 90.0, GunItem.Snd.PISTOL, GunItem.Mode.BULLET, 0.0F, 4.5F)));
        reg(WEAPONS, "m92_pistol", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(5.5F, 3, false, "pistol_bullet", 1, 0.012F, 75.0, GunItem.Snd.PISTOL, GunItem.Mode.BULLET, 0.0F, 2.0F)));
        reg(WEAPONS, "prototype_17", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(5.0F, 2, true, "pistol_bullet", 1, 0.02F, 70.0, GunItem.Snd.PISTOL, GunItem.Mode.BULLET, 0.0F, 1.4F)));
        reg(WEAPONS, "nailgun", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(4.0F, 5, true, "nails", 1, 0.02F, 40.0, GunItem.Snd.NAIL, GunItem.Mode.BULLET, 0.0F, 0.6F)));
        reg(WEAPONS, "double_barrel_shotgun", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(2.0F, 20, false, "buckshot", 9, 0.07F, 45.0, GunItem.Snd.SHOTGUN, GunItem.Mode.BULLET, 0.0F, 6.0F)));
        reg(WEAPONS, "pump_shotgun", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(2.0F, 22, false, "buckshot", 9, 0.06F, 50.0, GunItem.Snd.SHOTGUN, GunItem.Mode.BULLET, 0.0F, 5.0F)));
        reg(WEAPONS, "spas12", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(2.0F, 12, false, "buckshot", 9, 0.065F, 50.0, GunItem.Snd.SHOTGUN, GunItem.Mode.BULLET, 0.0F, 4.5F)));
        reg(WEAPONS, "m4_shotgun", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(2.0F, 9, false, "buckshot", 9, 0.07F, 50.0, GunItem.Snd.SHOTGUN, GunItem.Mode.BULLET, 0.0F, 4.0F)));
        reg(WEAPONS, "custom_smg", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(4.0F, 2, true, "pistol_bullet", 1, 0.03F, 60.0, GunItem.Snd.PISTOL, GunItem.Mode.BULLET, 0.0F, 1.0F)));
        reg(WEAPONS, "thompson", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(4.5F, 2, true, "pistol_bullet", 1, 0.028F, 65.0, GunItem.Snd.PISTOL, GunItem.Mode.BULLET, 0.0F, 1.2F)));
        reg(WEAPONS, "mp5a4", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(4.0F, 2, true, "pistol_bullet", 1, 0.022F, 70.0, GunItem.Snd.PISTOL, GunItem.Mode.BULLET, 0.0F, 0.9F)));
        reg(WEAPONS, "semi_auto_rifle", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(6.5F, 4, false, "rifle_ammo", 1, 0.008F, 120.0, GunItem.Snd.RIFLE, GunItem.Mode.BULLET, 0.0F, 2.5F)));
        reg(WEAPONS, "bolt_action_rifle", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(14.0F, 25, false, "rifle_ammo", 1, 0.0F, 160.0, GunItem.Snd.SNIPER, GunItem.Mode.BULLET, 0.0F, 5.0F)));
        reg(WEAPONS, "l96_rifle", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(17.0F, 30, false, "rifle_ammo", 1, 0.0F, 200.0, GunItem.Snd.SNIPER, GunItem.Mode.BULLET, 0.0F, 6.0F)));
        reg(WEAPONS, "m39_rifle", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(8.0F, 5, false, "rifle_ammo", 1, 0.005F, 150.0, GunItem.Snd.RIFLE, GunItem.Mode.BULLET, 0.0F, 3.0F)));
        reg(WEAPONS, "assault_rifle", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(7.0F, 3, true, "rifle_ammo", 1, 0.022F, 110.0, GunItem.Snd.RIFLE, GunItem.Mode.BULLET, 0.0F, 1.6F)));
        reg(WEAPONS, "lr300", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(6.5F, 3, true, "rifle_ammo", 1, 0.015F, 120.0, GunItem.Snd.RIFLE, GunItem.Mode.BULLET, 0.0F, 1.2F)));
        reg(WEAPONS, "m249", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(6.0F, 2, true, "rifle_ammo", 1, 0.03F, 120.0, GunItem.Snd.RIFLE, GunItem.Mode.BULLET, 0.0F, 1.3F)));
        reg(WEAPONS, "hmlmg", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(7.0F, 2, true, "rifle_ammo", 1, 0.035F, 100.0, GunItem.Snd.RIFLE, GunItem.Mode.BULLET, 0.0F, 1.8F)));
        reg(WEAPONS, "rocket_launcher", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(0.0F, 40, false, "rocket", 1, 0.0F, 90.0, GunItem.Snd.LAUNCHER, GunItem.Mode.EXPLOSIVE, 3.5F, 6.0F)));
        reg(WEAPONS, "mgl", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(0.0F, 12, false, "grenade_40mm", 1, 0.0F, 70.0, GunItem.Snd.LAUNCHER, GunItem.Mode.EXPLOSIVE, 2.0F, 3.0F)));
        reg(WEAPONS, "flamethrower", () -> new GunItem(new Item.Properties().stacksTo(1), new GunItem.Stats(1.5F, 2, true, "low_grade_fuel", 1, 0.0F, 8.0, GunItem.Snd.FLAME, GunItem.Mode.FLAME, 0.0F, 0.15F)));
        reg(WEAPONS, "hunting_bow", () -> new BowItem(new Item.Properties().durability(384)));
        reg(WEAPONS, "compound_bow", () -> new BowItem(new Item.Properties().durability(700)));
        reg(WEAPONS, "crossbow", () -> new CrossbowItem(new Item.Properties().durability(465)));
        reg(WEAPONS, "f1_grenade", () -> new ThrowableExplosive(new Item.Properties().stacksTo(16), ThrowableExplosive.Kind.F1));
        reg(WEAPONS, "beancan_grenade", () -> new ThrowableExplosive(new Item.Properties().stacksTo(16), ThrowableExplosive.Kind.BEANCAN));
        reg(WEAPONS, "satchel_charge", () -> new ThrowableExplosive(new Item.Properties().stacksTo(16), ThrowableExplosive.Kind.SATCHEL));
        reg(WEAPONS, "timed_explosive_charge", () -> new ThrowableExplosive(new Item.Properties().stacksTo(16), ThrowableExplosive.Kind.C4));
        reg(WEAPONS, "molotov_cocktail", () -> new ThrowableExplosive(new Item.Properties().stacksTo(16), ThrowableExplosive.Kind.MOLOTOV));
        // ---- обвесы
        reg(WEAPONS, "simple_handmade_sight", () -> new Item(new Item.Properties().stacksTo(1)));
        reg(WEAPONS, "holosight", () -> new Item(new Item.Properties().stacksTo(1)));
        reg(WEAPONS, "scope_8x", () -> new Item(new Item.Properties().stacksTo(1)));
        reg(WEAPONS, "variable_scope", () -> new Item(new Item.Properties().stacksTo(1)));
        reg(WEAPONS, "military_silencer", () -> new Item(new Item.Properties().stacksTo(1)));
        reg(WEAPONS, "oil_filter_silencer", () -> new Item(new Item.Properties().stacksTo(1)));
        reg(WEAPONS, "soda_can_silencer", () -> new Item(new Item.Properties().stacksTo(1)));
        reg(WEAPONS, "muzzle_brake", () -> new Item(new Item.Properties().stacksTo(1)));
        reg(WEAPONS, "muzzle_boost", () -> new Item(new Item.Properties().stacksTo(1)));
        reg(WEAPONS, "weapon_flashlight", () -> new Item(new Item.Properties().stacksTo(1)));
        reg(WEAPONS, "weapon_lasersight", () -> new Item(new Item.Properties().stacksTo(1)));
        // ---- одежда и броня
        reg(ARMOR, "burlap_headwear", () -> new ArmorItem(RustArmorMaterial.BURLAP, ArmorItem.Type.HELMET, new Item.Properties()));
        reg(ARMOR, "burlap_shirt", () -> new ArmorItem(RustArmorMaterial.BURLAP, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
        reg(ARMOR, "burlap_trousers", () -> new ArmorItem(RustArmorMaterial.BURLAP, ArmorItem.Type.LEGGINGS, new Item.Properties()));
        reg(ARMOR, "burlap_shoes", () -> new ArmorItem(RustArmorMaterial.BURLAP, ArmorItem.Type.BOOTS, new Item.Properties()));
        reg(ARMOR, "hide_vest", () -> new ArmorItem(RustArmorMaterial.HIDE, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
        reg(ARMOR, "hide_pants", () -> new ArmorItem(RustArmorMaterial.HIDE, ArmorItem.Type.LEGGINGS, new Item.Properties()));
        reg(ARMOR, "hide_boots", () -> new ArmorItem(RustArmorMaterial.HIDE, ArmorItem.Type.BOOTS, new Item.Properties()));
        reg(ARMOR, "hide_skirt", () -> new ArmorItem(RustArmorMaterial.HIDE, ArmorItem.Type.LEGGINGS, new Item.Properties()));
        reg(ARMOR, "hide_halterneck", () -> new ArmorItem(RustArmorMaterial.HIDE, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
        reg(ARMOR, "wood_armor_helmet", () -> new ArmorItem(RustArmorMaterial.WOOD, ArmorItem.Type.HELMET, new Item.Properties()));
        reg(ARMOR, "wood_chestplate", () -> new ArmorItem(RustArmorMaterial.WOOD, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
        reg(ARMOR, "wood_armor_pants", () -> new ArmorItem(RustArmorMaterial.WOOD, ArmorItem.Type.LEGGINGS, new Item.Properties()));
        reg(ARMOR, "road_sign_jacket", () -> new ArmorItem(RustArmorMaterial.ROADSIGN, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
        reg(ARMOR, "road_sign_kilt", () -> new ArmorItem(RustArmorMaterial.ROADSIGN, ArmorItem.Type.LEGGINGS, new Item.Properties()));
        reg(ARMOR, "coffee_can_helmet", () -> new ArmorItem(RustArmorMaterial.METAL, ArmorItem.Type.HELMET, new Item.Properties()));
        reg(ARMOR, "metal_facemask", () -> new ArmorItem(RustArmorMaterial.METAL, ArmorItem.Type.HELMET, new Item.Properties()));
        reg(ARMOR, "metal_chest_plate", () -> new ArmorItem(RustArmorMaterial.METAL, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
        reg(ARMOR, "bone_helmet", () -> new ArmorItem(RustArmorMaterial.BONE, ArmorItem.Type.HELMET, new Item.Properties()));
        reg(ARMOR, "bone_armor", () -> new ArmorItem(RustArmorMaterial.BONE, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
        reg(ARMOR, "heavy_plate_helmet", () -> new ArmorItem(RustArmorMaterial.HEAVY, ArmorItem.Type.HELMET, new Item.Properties()));
        reg(ARMOR, "heavy_plate_jacket", () -> new ArmorItem(RustArmorMaterial.HEAVY, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
        reg(ARMOR, "heavy_plate_pants", () -> new ArmorItem(RustArmorMaterial.HEAVY, ArmorItem.Type.LEGGINGS, new Item.Properties()));
        reg(ARMOR, "hazmat_hood", () -> new ArmorItem(RustArmorMaterial.HAZMAT, ArmorItem.Type.HELMET, new Item.Properties()));
        reg(ARMOR, "hazmat_jacket", () -> new ArmorItem(RustArmorMaterial.HAZMAT, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
        reg(ARMOR, "hazmat_pants", () -> new ArmorItem(RustArmorMaterial.HAZMAT, ArmorItem.Type.LEGGINGS, new Item.Properties()));
        reg(ARMOR, "hazmat_boots", () -> new ArmorItem(RustArmorMaterial.HAZMAT, ArmorItem.Type.BOOTS, new Item.Properties()));
        reg(ARMOR, "riot_helmet", () -> new ArmorItem(RustArmorMaterial.RIOT, ArmorItem.Type.HELMET, new Item.Properties()));
        reg(ARMOR, "balaclava", () -> new ArmorItem(RustArmorMaterial.CLOTH, ArmorItem.Type.HELMET, new Item.Properties()));
        reg(ARMOR, "bandana_mask", () -> new ArmorItem(RustArmorMaterial.CLOTH, ArmorItem.Type.HELMET, new Item.Properties()));
        reg(ARMOR, "beenie_hat", () -> new ArmorItem(RustArmorMaterial.CLOTH, ArmorItem.Type.HELMET, new Item.Properties()));
        reg(ARMOR, "tshirt", () -> new ArmorItem(RustArmorMaterial.CLOTH, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
        reg(ARMOR, "hoodie", () -> new ArmorItem(RustArmorMaterial.CLOTH, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
        reg(ARMOR, "pants", () -> new ArmorItem(RustArmorMaterial.CLOTH, ArmorItem.Type.LEGGINGS, new Item.Properties()));
        reg(ARMOR, "boots", () -> new ArmorItem(RustArmorMaterial.LEATHER, ArmorItem.Type.BOOTS, new Item.Properties()));
        reg(ARMOR, "diving_mask", () -> new ArmorItem(RustArmorMaterial.WETSUIT, ArmorItem.Type.HELMET, new Item.Properties()));
        reg(ARMOR, "wetsuit", () -> new ArmorItem(RustArmorMaterial.WETSUIT, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.rustcraft"))
                    .icon(() -> new ItemStack(SCRAP.get()))
                    .displayItems((params, out) -> MISC.forEach(e -> out.accept(e.get())))
                    .build());

    public static final RegistryObject<CreativeModeTab> TAB_WEAPONS = TABS.register("weapons",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.rustcraft.weapons"))
                    .icon(() -> new ItemStack(get("assault_rifle")))
                    .displayItems((params, out) -> WEAPONS.forEach(e -> out.accept(e.get())))
                    .build());

    public static final RegistryObject<CreativeModeTab> TAB_ARMOR = TABS.register("armor",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.rustcraft.armor"))
                    .icon(() -> new ItemStack(get("heavy_plate_jacket")))
                    .displayItems((params, out) -> ARMOR.forEach(e -> out.accept(e.get())))
                    .build());
}
