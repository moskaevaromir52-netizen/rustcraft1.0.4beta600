package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Киянка (Hammer). Пока она в руках, при взгляде на постройку показывается HP и сколько
 * взрывчатки нужно для рейда. ПКМ по воздуху - выбрать уровень улучшения (дерево/камень/металл/бронированный),
 * ПКМ по постройке - улучшить (HP полное) или починить (если не было урона последние 30 секунд),
 * Shift+ПКМ - снести (первые 10 минут после постройки).
 */
public class HammerItem extends SwordItem {

    public HammerItem(Properties props) {
        super(Tiers.IRON, 1, -2.6F, props);
    }

    public static int targetTier(ItemStack stack) {
        int t = stack.hasTag() ? stack.getTag().getInt("tier") : 0;
        return (t < 0 || t > 3) ? 0 : t;
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide || !selected || !(entity instanceof Player p) || p.tickCount % 5 != 0) return;
        Vec3 eye = p.getEyePosition();
        Vec3 end = eye.add(p.getLookAngle().scale(7.0));
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (hit.getType() != HitResult.Type.BLOCK || !(level instanceof ServerLevel sl)) return;
        BuildingData.Piece piece = BuildingData.get(sl).at(hit.getBlockPos());
        if (piece != null) p.displayClientMessage(StructureDamage.hud(piece), true);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            int t = (targetTier(stack) + 1) % 4;
            stack.getOrCreateTag().putInt("tier", t);
            player.displayClientMessage(Component.literal("§6Киянка: улучшение до §f" + BuildingBlock.TIER_NAMES[t]
                    + " §7(материал: " + BuildingPlanner.MATERIAL_NAMES[t] + ")"), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    private static void msg(Player p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        Player p = ctx.getPlayer();
        BlockPos pos = ctx.getClickedPos();
        if (p == null || !(level.getBlockState(pos).getBlock() instanceof BuildingBlock)) {
            return InteractionResult.PASS;
        }
        if (!(level instanceof ServerLevel sl)) return InteractionResult.SUCCESS;

        BuildingData data = BuildingData.get(sl);
        BuildingData.Piece piece = data.at(pos);
        if (piece == null) {
            msg(p, "§cЭто не элемент постройки");
            return InteractionResult.SUCCESS;
        }
        if (!ClaimData.get(sl).canBuild(pos, p.getUUID())) {
            msg(p, "§cПриватная территория (Tool Cupboard)");
            return InteractionResult.SUCCESS;
        }
        boolean creative = p.getAbilities().instabuild;
        long now = sl.getGameTime();

        // ---- снос
        if (p.isShiftKeyDown()) {
            boolean inWindow = piece.placed < 0 || now - piece.placed <= StructureHealth.DEMOLISH_WINDOW;
            if (!creative && !inWindow) {
                msg(p, "§cСнести можно только в первые 10 минут после постройки");
                return InteractionResult.SUCCESS;
            }
            List<Long> copy = new ArrayList<>(piece.blocks);
            for (long l : copy) {
                sl.setBlock(BlockPos.of(l), Blocks.AIR.defaultBlockState(), 3);
            }
            data.removePiece(piece);
            sl.playSound(null, pos, SoundEvents.WOOD_BREAK, SoundSource.BLOCKS, 1.0F, 0.8F);
            msg(p, "§eЭлемент снесён");
            return InteractionResult.SUCCESS;
        }

        BuildingPlanner.Kind kind = BuildingPlanner.Kind.values()[piece.type];
        int target = targetTier(ctx.getItemInHand());

        // ---- улучшение (HP восстанавливается полностью)
        if (StructureHealth.rank(piece.tier) < target) {
            int units = BuildingPlanner.unitsFor(kind, target);
            if (!creative) {
                int have = BuildingPlanner.count(p, target);
                if (have < units) {
                    msg(p, "§cНужно " + units + " " + BuildingPlanner.MATERIAL_NAMES[target] + " (есть " + have + ")");
                    return InteractionResult.SUCCESS;
                }
                BuildingPlanner.take(p, target, units);
            }
            for (long l : piece.blocks) {
                BlockPos b = BlockPos.of(l);
                if (sl.getBlockState(b).getBlock() instanceof BuildingBlock) {
                    sl.setBlock(b, ModBlocks.building(target).defaultBlockState(), 3);
                }
            }
            piece.tier = target;
            piece.hp = StructureHealth.max(target);
            data.setDirty();
            sl.playSound(null, pos, SoundEvents.ANVIL_USE, SoundSource.BLOCKS, 0.6F, 1.2F);
            msg(p, "§aУлучшено до: §f" + BuildingBlock.TIER_NAMES[target]);
            return InteractionResult.SUCCESS;
        }

        // ---- ремонт
        float max = StructureHealth.max(piece.tier);
        if (piece.hp < max) {
            if (!creative && now - piece.lastDamage < StructureHealth.REPAIR_DELAY) {
                long left = (StructureHealth.REPAIR_DELAY - (now - piece.lastDamage)) / 20 + 1;
                msg(p, "§cНедавно повреждено: чинить можно через " + left + " с");
                return InteractionResult.SUCCESS;
            }
            float missing = 1.0F - piece.hp / max;
            int units = Math.max(1, (int) Math.ceil(BuildingPlanner.unitsFor(kind, piece.tier) * missing));
            if (!creative) {
                int have = BuildingPlanner.count(p, piece.tier);
                if (have < units) {
                    msg(p, "§cДля ремонта нужно " + units + " " + BuildingPlanner.MATERIAL_NAMES[piece.tier]
                            + " (есть " + have + ")");
                    return InteractionResult.SUCCESS;
                }
                BuildingPlanner.take(p, piece.tier, units);
            }
            piece.hp = max;
            data.setDirty();
            sl.playSound(null, pos, SoundEvents.ANVIL_USE, SoundSource.BLOCKS, 0.5F, 1.6F);
            p.displayClientMessage(Component.literal("§aОтремонтировано  ").append(StructureDamage.hud(piece)), true);
            return InteractionResult.SUCCESS;
        }

        msg(p, "§cУже " + BuildingBlock.TIER_NAMES[piece.tier] + ", HP полное. Выберите уровень выше (ПКМ по воздуху)");
        return InteractionResult.SUCCESS;
    }
}
