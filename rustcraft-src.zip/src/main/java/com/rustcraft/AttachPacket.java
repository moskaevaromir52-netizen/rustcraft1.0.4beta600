package com.rustcraft;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Клиент -> сервер: установить/снять обвес или переключить фонарь/лазер. */
public class AttachPacket {
    public static final byte INSTALL = 0;
    public static final byte REMOVE = 1;
    public static final byte TOGGLE = 2;

    private final byte action;
    private final String arg;

    public AttachPacket(byte action, String arg) {
        this.action = action;
        this.arg = arg;
    }

    public static void encode(AttachPacket m, FriendlyByteBuf buf) {
        buf.writeByte(m.action);
        buf.writeUtf(m.arg, 64);
    }

    public static AttachPacket decode(FriendlyByteBuf buf) {
        return new AttachPacket(buf.readByte(), buf.readUtf(64));
    }

    public static void handle(AttachPacket m, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer p = c.getSender();
            if (p == null) return;
            switch (m.action) {
                case INSTALL -> Attachments.install(p, m.arg);
                case REMOVE -> Attachments.remove(p, m.arg);
                case TOGGLE -> Attachments.toggle(p);
                default -> {
                }
            }
        });
        c.setPacketHandled(true);
    }
}
