package com.rustcraft;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/**
 * Дерево изучения и крафта верстаков.
 * WEAPON - сначала изучить за скрап, потом крафтить (железо + компоненты).
 * SUPPLY - компоненты и патроны: изучать не нужно, нужен только верстак нужного уровня.
 * Стоимость изучения - по тирам Rust (75/125/250/500 скрапа), уменьшена для Minecraft.
 * Id ингредиента без двоеточия = предмет мода.
 */
public final class WeaponTree {
    public enum Kind { WEAPON, SUPPLY }

    public record Ing(String item, int count) {
    }

    /** bit - номер бита изучения (только у WEAPON), -1 у SUPPLY. */
    public record Entry(String id, Kind kind, int tier, int scrap, int outCount, List<Ing> cost, int bit) {
    }

    public static final List<Entry> ALL = new ArrayList<>();
    public static final List<Entry> WEAPONS = new ArrayList<>();
    public static final List<Entry> ATTACHMENTS = new ArrayList<>();
    public static final List<Entry> SUPPLIES = new ArrayList<>();
    private static int bits = 0;

    private static final String IRON = "minecraft:iron_ingot";
    private static final String GUNPOWDER = "minecraft:gunpowder";
    private static final String STRING = "minecraft:string";
    private static final String PIPE = "metal_pipe";
    private static final String SPRING = "metal_spring";
    private static final String GEARS = "gears";
    private static final String ROPE = "rope";
    private static final String SEMI = "semi_auto_body";
    private static final String SMG = "smg_body";
    private static final String RIFLE = "rifle_body";
    private static final String SCRAP = "scrap";

    private static Ing i(String item, int n) {
        return new Ing(item, n);
    }

    private static void weapon(String id, int tier, int scrap, Ing... cost) {
        Entry e = new Entry(id, Kind.WEAPON, tier, scrap, 1, List.of(cost), bits++);
        ALL.add(e);
        WEAPONS.add(e);
    }

    /** Обвесы: тоже изучаются за скрап, лежат на отдельной вкладке. */
    private static void attach(String id, int tier, int scrap, Ing... cost) {
        Entry e = new Entry(id, Kind.WEAPON, tier, scrap, 1, List.of(cost), bits++);
        ALL.add(e);
        ATTACHMENTS.add(e);
    }

    private static void supply(String id, int tier, int out, Ing... cost) {
        Entry e = new Entry(id, Kind.SUPPLY, tier, 0, out, List.of(cost), -1);
        ALL.add(e);
        SUPPLIES.add(e);
    }

    static {
        // ================= ВЕРСТАК 1 =================
        weapon("eoka_pistol", 1, 15, i(IRON, 3), i(PIPE, 1));
        weapon("waterpipe_shotgun", 1, 25, i(IRON, 6));
        weapon("revolver", 1, 30, i(IRON, 6), i(PIPE, 1));
        weapon("double_barrel_shotgun", 1, 35, i(IRON, 8), i(PIPE, 2));
        weapon("nailgun", 1, 30, i(IRON, 6), i(PIPE, 1), i(GEARS, 1));
        weapon("crossbow", 1, 25, i(IRON, 4), i(ROPE, 2), i(GEARS, 1));
        weapon("beancan_grenade", 1, 20, i(IRON, 1), i(GUNPOWDER, 3), i(STRING, 1));
        weapon("molotov_cocktail", 1, 20, i("minecraft:glass_bottle", 1), i("low_grade_fuel", 2), i(STRING, 1));
        weapon("salvaged_axe", 1, 20, i(IRON, 5));
        weapon("salvaged_hammer", 1, 20, i(IRON, 5));
        weapon("salvaged_icepick", 1, 20, i(IRON, 4));
        weapon("salvaged_cleaver", 1, 25, i(IRON, 5));
        weapon("salvaged_sword", 1, 25, i(IRON, 6));

        // ================= ВЕРСТАК 2 =================
        weapon("semi_auto_pistol", 2, 60, i(SEMI, 1), i(IRON, 4));
        weapon("python_revolver", 2, 75, i(SEMI, 1), i(SPRING, 1), i(IRON, 6));
        weapon("pump_shotgun", 2, 55, i(PIPE, 2), i(SPRING, 1), i(IRON, 8));
        weapon("custom_smg", 2, 70, i(SMG, 1), i(SPRING, 1), i(IRON, 8));
        weapon("thompson", 2, 80, i(SMG, 1), i(SPRING, 1), i(IRON, 10));
        weapon("semi_auto_rifle", 2, 85, i(SEMI, 1), i(SPRING, 1), i(IRON, 10));
        weapon("flamethrower", 2, 90, i("propane_tank", 1), i(PIPE, 2), i(GEARS, 2), i(IRON, 8));
        weapon("compound_bow", 2, 60, i(IRON, 6), i(ROPE, 3), i(GEARS, 2));
        weapon("f1_grenade", 2, 40, i(IRON, 3), i(GUNPOWDER, 5));
        weapon("satchel_charge", 2, 60, i("beancan_grenade", 4), i(ROPE, 1));
        weapon("machete", 2, 40, i(IRON, 8));
        weapon("combat_knife", 2, 45, i(IRON, 6));
        weapon("longsword", 2, 55, i(IRON, 12));
        weapon("mace", 2, 55, i(IRON, 12));

        // ================= ВЕРСТАК 3 =================
        weapon("m92_pistol", 3, 110, i(SEMI, 1), i(SPRING, 2), i(IRON, 8));
        weapon("prototype_17", 3, 120, i(SEMI, 1), i(SPRING, 2), i(IRON, 10));
        weapon("spas12", 3, 120, i(SEMI, 1), i(SPRING, 2), i(PIPE, 2), i(IRON, 10));
        weapon("m4_shotgun", 3, 140, i(SEMI, 1), i(SPRING, 2), i(PIPE, 2), i(IRON, 12));
        weapon("mp5a4", 3, 130, i(SMG, 1), i(SPRING, 2), i(IRON, 12));
        weapon("m39_rifle", 3, 150, i(SEMI, 1), i(SPRING, 2), i(IRON, 12));
        weapon("bolt_action_rifle", 3, 140, i(RIFLE, 1), i(SPRING, 1), i(IRON, 14));
        weapon("l96_rifle", 3, 180, i(RIFLE, 1), i(IRON, 24));
        weapon("assault_rifle", 3, 160, i(RIFLE, 1), i(SPRING, 4), i(IRON, 20));
        weapon("lr300", 3, 170, i(RIFLE, 1), i(SPRING, 3), i(IRON, 20));
        weapon("m249", 3, 200, i(RIFLE, 1), i(SPRING, 4), i(IRON, 24));
        weapon("hmlmg", 3, 190, i(RIFLE, 1), i(SPRING, 3), i(IRON, 18));
        weapon("rocket_launcher", 3, 180, i(PIPE, 4), i(GEARS, 2), i(SPRING, 2), i(IRON, 12));
        weapon("mgl", 3, 200, i(SEMI, 1), i(PIPE, 3), i(SPRING, 3), i(IRON, 16));
        weapon("timed_explosive_charge", 3, 120, i(GUNPOWDER, 20), i(ROPE, 2), i(GEARS, 2), i(IRON, 4));
        weapon("jackhammer", 3, 100, i(GEARS, 4), i(PIPE, 2), i(SPRING, 2), i(IRON, 10));
        weapon("chainsaw", 3, 110, i(GEARS, 4), i(PIPE, 3), i(SPRING, 2), i(IRON, 12));

        // ================= ОБВЕСЫ =================
        String glass = "minecraft:glass_pane";
        String redstone = "minecraft:redstone";
        attach("simple_handmade_sight", 1, 15, i(IRON, 2));
        attach("soda_can_silencer", 1, 20, i(IRON, 2), i(PIPE, 1));
        attach("oil_filter_silencer", 1, 25, i(IRON, 3), i(PIPE, 1));
        attach("weapon_flashlight", 1, 20, i(IRON, 2), i("minecraft:glowstone_dust", 2), i(glass, 1));
        attach("holosight", 2, 50, i(IRON, 3), i(glass, 2), i(redstone, 2), i(GEARS, 1));
        attach("muzzle_brake", 2, 40, i(IRON, 6), i(PIPE, 1));
        attach("muzzle_boost", 2, 45, i(IRON, 6), i(PIPE, 1), i(GEARS, 1));
        attach("weapon_lasersight", 2, 55, i(IRON, 3), i(redstone, 3), i(glass, 1), i(GEARS, 1));
        attach("military_silencer", 3, 90, i(IRON, 8), i(PIPE, 2), i(GEARS, 1));
        attach("scope_8x", 3, 100, i(IRON, 10), i(glass, 3), i(GEARS, 2), i(PIPE, 1));
        attach("variable_scope", 3, 130, i(IRON, 14), i(glass, 4), i(GEARS, 3), i(SPRING, 1));

        // ================= КОМПОНЕНТЫ =================
        supply("metal_pipe", 1, 1, i(IRON, 2));
        supply("rope", 1, 1, i(STRING, 4));
        supply("gears", 1, 1, i(IRON, 3), i(SCRAP, 1));
        supply("metal_spring", 2, 1, i(IRON, 3), i(SCRAP, 3));
        supply("semi_auto_body", 2, 1, i(IRON, 6), i(PIPE, 1), i(GEARS, 1), i(SCRAP, 4));
        supply("smg_body", 2, 1, i(IRON, 8), i(PIPE, 1), i(GEARS, 2), i(SCRAP, 5));
        supply("propane_tank", 2, 1, i(IRON, 5), i(PIPE, 1));
        supply("rifle_body", 3, 1, i(IRON, 12), i(PIPE, 2), i(GEARS, 2), i(SCRAP, 10));
        // ================= ПАТРОНЫ =================
        supply("handmade_shell", 1, 2, i(IRON, 1), i(GUNPOWDER, 1));
        supply("pistol_bullet", 1, 8, i(IRON, 1), i(GUNPOWDER, 1));
        supply("nails", 1, 12, i(IRON, 1));
        supply("buckshot", 2, 4, i(IRON, 1), i(GUNPOWDER, 2));
        supply("rifle_ammo", 2, 8, i(IRON, 2), i(GUNPOWDER, 2));
        supply("low_grade_fuel", 2, 4, i("minecraft:coal", 2));
        supply("rocket", 3, 1, i(IRON, 4), i(GUNPOWDER, 8), i(PIPE, 1));
        supply("grenade_40mm", 3, 2, i(IRON, 2), i(GUNPOWDER, 4));
    }

    private WeaponTree() {
    }

    public static Item item(String id) {
        if (id.contains(":")) {
            Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(id));
            return it == null ? net.minecraft.world.item.Items.AIR : it;
        }
        return ModItems.get(id);
    }

    public static ItemStack stack(Entry e) {
        return new ItemStack(item(e.id()), e.outCount());
    }
}
