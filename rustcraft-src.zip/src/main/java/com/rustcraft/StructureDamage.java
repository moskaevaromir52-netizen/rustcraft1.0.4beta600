package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Урон по постройкам. Взрывчатка бьёт по HP целого элемента (стена, фундамент...),
 * количество зарядов для рейда получается из таблицы урона как в Rust.
 * Индексы урона: дерево, камень, металл, бронированный, хворост.
 */
public final class StructureDamage {

    public enum Source {
        BEANCAN("бобовок", 15.0F, 10.0F, 7.6F, 7.6F, 15.0F),
        F1("гранат F1", 12.0F, 4.0F, 2.5F, 2.5F, 12.0F),
        SATCHEL("сэтчелов", 75.0F, 51.5F, 43.5F, 43.5F, 75.0F),
        C4("C4", 550.0F, 275.0F, 275.0F, 275.0F, 550.0F),
        ROCKET("ракет", 137.0F, 137.0F, 125.0F, 137.0F, 350.0F),
        GRENADE40("гранат 40мм", 45.0F, 30.0F, 18.0F, 18.0F, 45.0F),
        MOLOTOV("молотовых", 20.0F, 0.0F, 0.0F, 0.0F, 20.0F);

        public final String label;
        private final float[] dmg;

        Source(String label, float... dmg) {
            this.label = label;
            this.dmg = dmg;
        }

        public float damage(int tier) {
            return dmg[Math.max(0, Math.min(dmg.length - 1, tier))];
        }

        /** Сколько таких зарядов нужно, чтобы снести элемент с текущим HP. */
        public int hitsToDestroy(float hp, int tier) {
            float d = damage(tier);
            return d <= 0.0F ? -1 : (int) Math.ceil(hp / d);
        }
    }

    private StructureDamage() {
    }

    // ------------------------------------------------------------ показ HP
    public static String bar(float hp, float max) {
        int n = 20;
        int filled = Math.max(0, Math.min(n, Math.round(hp / max * n)));
        float f = hp / max;
        String col = f > 0.6F ? "§a" : (f > 0.3F ? "§e" : "§c");
        return col + "█".repeat(filled) + "§8" + "█".repeat(n - filled);
    }

    public static String title(BuildingData.Piece p) {
        return BuildingPlanner.Kind.values()[p.type].title + " §7(" + BuildingBlock.TIER_NAMES[p.tier] + ")";
    }

    private static String fmt(float v) {
        return v == Math.floor(v) ? String.valueOf((int) v) : String.format("%.1f", v);
    }

    /** Строка для actionbar: название, HP, шкала и сколько зарядов нужно для рейда. */
    public static Component hud(BuildingData.Piece p) {
        float max = StructureHealth.max(p.tier);
        StringBuilder sb = new StringBuilder();
        sb.append("§6").append(title(p)).append("  §c❤ §f").append(fmt(Math.max(0, p.hp))).append("§7/§f")
                .append(fmt(max)).append("  ").append(bar(p.hp, max)).append("  §7| ");
        Source[] show = {Source.C4, Source.ROCKET, Source.SATCHEL, Source.BEANCAN};
        for (int i = 0; i < show.length; i++) {
            int n = show[i].hitsToDestroy(p.hp, p.tier);
            sb.append("§e").append(show[i].label).append(" §f").append(n < 0 ? "-" : "x" + n);
            if (i < show.length - 1) sb.append("§7, ");
        }
        return Component.literal(sb.toString());
    }

    // ------------------------------------------------------------ урон
    /** Взрыв в точке pos: находит элементы постройки рядом и бьёт по ним. */
    public static void explode(ServerLevel level, Vec3 pos, Source src, Player owner) {
        BuildingData data = BuildingData.get(level);
        double search = src == Source.ROCKET ? 2.6 : 3.3;
        int r = (int) Math.ceil(search);
        BlockPos c = BlockPos.containing(pos);
        Map<Integer, Double> dist = new HashMap<>();
        Map<Integer, BuildingData.Piece> found = new HashMap<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos b = c.offset(dx, dy, dz);
                    BuildingData.Piece p = data.at(b);
                    if (p == null) continue;
                    double d = pos.distanceTo(Vec3.atCenterOf(b));
                    if (d > search) continue;
                    Double old = dist.get(p.id);
                    if (old == null || d < old) {
                        dist.put(p.id, d);
                        found.put(p.id, p);
                    }
                }
            }
        }
        if (found.isEmpty()) return;
        List<BuildingData.Piece> sorted = new ArrayList<>(found.values());
        sorted.sort(Comparator.comparingDouble(p -> dist.get(p.id)));

        // ракета может задеть до 4 элементов, остальные взрывы - только ближайший
        int limit = src == Source.ROCKET ? 4 : 1;
        for (int i = 0; i < sorted.size() && i < limit; i++) {
            BuildingData.Piece p = sorted.get(i);
            if (i > 0 && dist.get(p.id) > 1.8) break;
            damage(level, data, p, src.damage(p.tier), owner, pos);
        }
    }

    public static void damage(ServerLevel level, BuildingData data, BuildingData.Piece p, float amount,
                              Player attacker, Vec3 at) {
        if (amount <= 0.0F) return;
        p.hp -= amount;
        p.lastDamage = level.getGameTime();
        data.setDirty();
        String name = title(p);
        if (p.hp <= 0.0F) {
            destroy(level, data, p);
            if (attacker instanceof ServerPlayer sp) {
                sp.displayClientMessage(Component.literal("§c✖ Разрушено: §f" + name), true);
            }
            return;
        }
        BlockPos near = null;
        double best = Double.MAX_VALUE;
        for (long l : p.blocks) {
            BlockPos b = BlockPos.of(l);
            double d = at.distanceToSqr(Vec3.atCenterOf(b));
            if (d < best) {
                best = d;
                near = b;
            }
        }
        if (near != null) {
            BlockState st = level.getBlockState(near);
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, st),
                    near.getX() + 0.5, near.getY() + 0.5, near.getZ() + 0.5, 8, 0.3, 0.3, 0.3, 0.05);
            if (p.hp < StructureHealth.max(p.tier) * 0.5F && level.random.nextInt(3) == 0) {
                level.sendParticles(ParticleTypes.SMOKE, near.getX() + 0.5, near.getY() + 1.0, near.getZ() + 0.5,
                        4, 0.3, 0.2, 0.3, 0.01);
            }
            level.playSound(null, near, st.getSoundType().getHitSound(), SoundSource.BLOCKS, 1.0F, 0.6F);
        }
        if (attacker instanceof ServerPlayer sp) {
            sp.displayClientMessage(Component.literal("§c-" + fmt(amount) + "  ").append(hud(p)), true);
        }
    }

    // ------------------------------------------------------------ разрушение
    public static void destroy(ServerLevel level, BuildingData data, BuildingData.Piece piece) {
        Set<Long> removed = new HashSet<>();
        destroyRaw(level, data, piece, removed);
        collapse(level, data, removed);
    }

    private static void destroyRaw(ServerLevel level, BuildingData data, BuildingData.Piece piece, Set<Long> removed) {
        List<Long> blocks = new ArrayList<>(piece.blocks);
        int k = 0;
        for (long l : blocks) {
            BlockPos b = BlockPos.of(l);
            BlockState st = level.getBlockState(b);
            if (st.getBlock() instanceof BuildingBlock) {
                if (k++ % 3 == 0) level.levelEvent(2001, b, Block.getId(st));
                level.setBlock(b, Blocks.AIR.defaultBlockState(), 3);
            }
            removed.add(l);
        }
        data.removePiece(piece);
        if (!blocks.isEmpty()) {
            BlockPos c = BlockPos.of(blocks.get(blocks.size() / 2));
            level.playSound(null, c, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 0.7F, 1.4F);
        }
    }

    /** Стены и лестницы, потерявшие опору под собой, обрушиваются (цепочкой). */
    private static void collapse(ServerLevel level, BuildingData data, Set<Long> removed) {
        boolean changed = true;
        while (changed) {
            changed = false;
            for (BuildingData.Piece p : data.all()) {
                if (p.type < 2 || p.blocks.isEmpty()) continue;
                int minY = Integer.MAX_VALUE;
                for (long l : p.blocks) minY = Math.min(minY, BlockPos.of(l).getY());
                boolean lost = false;
                boolean supported = false;
                for (long l : p.blocks) {
                    BlockPos b = BlockPos.of(l);
                    if (b.getY() != minY) continue;
                    BlockPos below = b.below();
                    if (removed.contains(below.asLong())) lost = true;
                    if (level.getBlockState(below).getBlock() instanceof BuildingBlock) supported = true;
                }
                if (lost && !supported) {
                    destroyRaw(level, data, p, removed);
                    changed = true;
                }
            }
        }
    }
}
