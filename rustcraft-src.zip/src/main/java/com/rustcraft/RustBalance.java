package com.rustcraft;

/** Все цифры баланса в одном месте: правь здесь. */
public final class RustBalance {
    private RustBalance() {
    }

    /** Сколько скрапа выпадает из бочки (включительно). */
    public static final int BARREL_SCRAP_MIN = 1;
    public static final int BARREL_SCRAP_MAX = 4;
    /** Прочность бочки в «очках удара». Рука = 1, меч = 2, топор/кирка = 3. */
    public static final int BARREL_HP = 8;
    /** Минимум тиков между ударами по бочке. */
    public static final int BARREL_HIT_DELAY = 6;

    /** Цена улучшения верстака в скрапе; индекс = уровень, до которого улучшаем. */
    public static final int[] UPGRADE_SCRAP = {0, 0, 30, 80};
}
