package com.rustcraft;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Окно обвесов (клавиша Z с оружием в руках): слоты сверху, доступные обвесы снизу. */
public class AttachmentScreen extends Screen {
    private static final int W = 232;
    private static final int H = 170;

    private int left;
    private int top;

    public AttachmentScreen() {
        super(Component.translatable("gui.rustcraft.attachments"));
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private ItemStack gun() {
        return minecraft == null || minecraft.player == null ? ItemStack.EMPTY : minecraft.player.getMainHandItem();
    }

    private boolean creative() {
        return minecraft != null && minecraft.player != null && minecraft.player.getAbilities().instabuild;
    }

    private int slotX(int i, int n) {
        return left + (W - n * 52) / 2 + i * 52 + 8;
    }

    private static final int SLOT_Y = 44;

    private List<Attachment> available(ItemStack gun) {
        List<Attachment> out = new ArrayList<>();
        for (Attachment a : Attachment.ALL) {
            if (!Attachments.fits(gun.getItem(), a)) continue;
            int have = minecraft == null || minecraft.player == null ? 0
                    : InvUtil.count(minecraft.player, ModItems.get(a.id));
            if (creative() || have > 0) out.add(a);
        }
        return out;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        ItemStack gun = gun();
        if (!(gun.getItem() instanceof GunItem)) {
            onClose();
            return;
        }
        renderBackground(g);
        g.fill(left - 2, top - 2, left + W + 2, top + H + 2, 0xFF3A3F45);
        g.fill(left, top, left + W, top + H, 0xFF1B1D20);
        g.drawString(font, gun.getHoverName(), left + 8, top + 8, 0xFFE0A030, false);
        g.renderItem(gun, left + W - 24, top + 4);

        List<Attachment.Slot> slots = Attachments.slots(gun.getItem());
        ItemStack tooltip = ItemStack.EMPTY;
        for (int i = 0; i < slots.size(); i++) {
            Attachment.Slot s = slots.get(i);
            int x = slotX(i, slots.size());
            g.drawCenteredString(font, Component.translatable("gui.rustcraft.slot." + s.key()), x + 18, top + 28, 0xFFBBBBBB);
            g.fill(x - 1, top + SLOT_Y - 1, x + 37, top + SLOT_Y + 37, 0xFF55595F);
            g.fill(x, top + SLOT_Y, x + 36, top + SLOT_Y + 36, 0xFF2D3035);
            Attachment a = Attachments.get(gun, s);
            if (a != null) {
                ItemStack st = new ItemStack(ModItems.get(a.id));
                g.pose().pushPose();
                g.pose().translate(x + 2, top + SLOT_Y + 2, 0);
                g.pose().scale(2.0F, 2.0F, 1.0F);
                g.renderItem(st, 0, 0);
                g.pose().popPose();
                if (mx >= x && mx < x + 36 && my >= top + SLOT_Y && my < top + SLOT_Y + 36) tooltip = st;
            }
        }

        g.drawString(font, Component.translatable("gui.rustcraft.available"), left + 8, top + 94, 0xFFBBBBBB, false);
        List<Attachment> av = available(gun);
        if (av.isEmpty()) {
            g.drawWordWrap(font, Component.translatable("gui.rustcraft.no_attachments"), left + 8, top + 108, W - 16, 0xFF888888);
        }
        for (int i = 0; i < av.size(); i++) {
            int x = left + 8 + (i % 10) * 21;
            int y = top + 108 + (i / 10) * 21;
            g.fill(x, y, x + 20, y + 20, 0xFF2D3035);
            ItemStack st = new ItemStack(ModItems.get(av.get(i).id));
            g.renderItem(st, x + 2, y + 2);
            if (mx >= x && mx < x + 20 && my >= y && my < y + 20) tooltip = st;
        }
        g.drawString(font, Component.translatable("gui.rustcraft.attach_hint"), left + 8, top + H - 14, 0xFF777777, false);
        super.render(g, mx, my, pt);
        if (!tooltip.isEmpty()) g.renderTooltip(font, tooltip, mx, my);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        ItemStack gun = gun();
        if (!(gun.getItem() instanceof GunItem)) return super.mouseClicked(mx, my, button);
        List<Attachment.Slot> slots = Attachments.slots(gun.getItem());
        for (int i = 0; i < slots.size(); i++) {
            int x = slotX(i, slots.size());
            if (mx >= x && mx < x + 36 && my >= top + SLOT_Y && my < top + SLOT_Y + 36) {
                if (Attachments.get(gun, slots.get(i)) != null) {
                    RustNet.CHANNEL.sendToServer(new AttachPacket(AttachPacket.REMOVE, slots.get(i).key()));
                }
                return true;
            }
        }
        List<Attachment> av = available(gun);
        for (int i = 0; i < av.size(); i++) {
            int x = left + 8 + (i % 10) * 21;
            int y = top + 108 + (i / 10) * 21;
            if (mx >= x && mx < x + 20 && my >= y && my < y + 20) {
                RustNet.CHANNEL.sendToServer(new AttachPacket(AttachPacket.INSTALL, av.get(i).id));
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (ClientKeys.ATTACH.matches(key, scan)) {
            onClose();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }
}
