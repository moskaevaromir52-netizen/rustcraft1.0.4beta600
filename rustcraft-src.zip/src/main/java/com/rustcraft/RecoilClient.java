package com.rustcraft;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Отдача в стиле Rust. У автоматов есть «паттерн»: первые выстрелы бьют слабее, затем
 * прицел уверенно уезжает вверх и качается влево-вправо (фаза качания своя у каждого оружия).
 * Одиночные выстрелы дают полный удар каждый раз. Компенсировать нужно мышью.
 * Заодно запускает анимацию оружия в руке (GunAnimClient).
 */
@Mod.EventBusSubscriber(modid = RustCraft.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class RecoilClient {
    private static long nextShot = 0;
    private static long lastShot = -1000;
    private static int shotIndex = 0;
    private static boolean wasDown = false;
    private static float pendingPitch = 0;
    private static float pendingYaw = 0;

    private RecoilClient() {
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        GunAnimClient.tick();
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.isPaused()) {
            pendingPitch = 0;
            pendingYaw = 0;
            return;
        }

        // плавно отдаём накопленную отдачу
        if (Math.abs(pendingPitch) > 0.01F || Math.abs(pendingYaw) > 0.01F) {
            float dp = pendingPitch * 0.5F;
            float dy = pendingYaw * 0.5F;
            pendingPitch -= dp;
            pendingYaw -= dy;
            p.setXRot(Mth.clamp(p.getXRot() - dp, -90.0F, 90.0F));
            p.setYRot(p.getYRot() + dy);
        }

        ItemStack held = p.getMainHandItem();
        boolean down = mc.options.keyAttack.isDown() && mc.screen == null && mc.mouseHandler.isMouseGrabbed();
        boolean aim = AimState.aiming();
        if (down && held.getItem() instanceof GunItem gun) {
            GunItem.Stats s = gun.stats();
            Attachments.Mods mods = Attachments.mods(held);
            long now = mc.level.getGameTime();
            if ((s.auto() || !wasDown) && now >= nextShot && gun.hasAmmo(p)) {
                nextShot = now + mods.delay(s.delay());
                RustNet.CHANNEL.sendToServer(new FirePacket(aim));
                if (now - lastShot > Math.max(10, s.delay() + 6)) shotIndex = 0;
                lastShot = now;

                float rnd = 0.92F + p.getRandom().nextFloat() * 0.16F;
                float ramp = s.auto() ? 0.55F + 0.45F * Math.min(1.0F, shotIndex / 7.0F) : 1.0F;
                float rec = s.recoil() * mods.recoil() * (aim ? 0.8F : 1.0F);
                pendingPitch += rec * ramp * rnd;

                var key = ForgeRegistries.ITEMS.getKey(gun);
                float phase = key == null ? 0 : (key.getPath().hashCode() & 7) * 0.8F;
                float sway = Mth.sin(shotIndex * 0.55F + phase) * rec * 0.45F
                        * (s.auto() ? Math.min(1.0F, shotIndex / 4.0F) : 0.0F);
                float jitter = (p.getRandom().nextFloat() - 0.5F) * rec * 0.25F;
                pendingYaw += sway + jitter;

                shotIndex++;
                GunAnimClient.shot(rec);
            }
        }
        wasDown = down;
    }
}
